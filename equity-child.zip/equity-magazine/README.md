# equity-magazine
